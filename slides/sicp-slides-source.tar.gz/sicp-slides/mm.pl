my $f = sub {
    my ($x) = @_;
    return $x + 4;
};

print $f->(3) . "\n";
